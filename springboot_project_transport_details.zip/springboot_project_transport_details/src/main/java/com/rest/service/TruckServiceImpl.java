package com.rest.service;

import java.util.List;

import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rest.entity.Truck;
import com.rest.repository.TruckRepository;

@Service
public class TruckServiceImpl implements TruckService{ 
	
	@Autowired
	private TruckRepository repo;

	@Override
	public Truck createTruck(Truck tr) {
			
		return repo.save(tr);
	}

	@Override
	public List<Truck> getAllTruck() {
		
		return repo.findAll();
	}

	@Override
	public Truck updateTruck(int shipperId, Truck truck) {
	
		truck.setShipperId(shipperId);
		return repo.save(truck);
	}

	@Override
	public String deleteTruck(int shipperId) {
		Optional truck = repo.findById(shipperId);
	if(truck.get() != null) {
		repo.delete((Truck)truck.get());
		return "delete Successfully";
	}
		return "Truck not available" + shipperId+" shipperId";
	}

}
