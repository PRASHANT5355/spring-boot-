package com.rest.service;

import java.util.List;

import com.rest.entity.Truck;

public interface TruckService {
	
	public Truck createTruck(Truck tr);
	public List<Truck> getAllTruck();
	public Truck updateTruck(int shipperId,Truck truck);
	public String deleteTruck(int shipperId);
	
	
	

}
