package com.rest.entity;


import java.time.LocalDate;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name ="truck_dtls")
public class Truck {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	
	private int shipperId;
	private LocalDate Date;
	private String loadingPoint;
	private String unloadingPoint;
	private String productType;
	private String truckType;
	private int noOfTruck;
	private float weight;
	private String comment;
	
	public int getShipperId() {
		return shipperId;
	}
	public void setShipperId(int shipperId) {
		this.shipperId = shipperId;
	}
	public LocalDate getDate() {
		return Date;
	}
	public void setDate(LocalDate date) {
		Date = date;
	}
	public String getLoadingPoint() {
		return loadingPoint;
	}
	public void setLoadingPoint(String loadingPoint) {
		this.loadingPoint = loadingPoint;
	}
	public String getUnloadingPoint() {
		return unloadingPoint;
	}
	public void setUnloadingPoint(String unloadingPoint) {
		this.unloadingPoint = unloadingPoint;
	}
	public String getProductType() {
		return productType;
	}
	public void setProductType(String productType) {
		this.productType = productType;
	}
	public String getTruckType() {
		return truckType;
	}
	public void setTruckType(String truckType) {
		this.truckType = truckType;
	}
	public int getNoOfTruck() {
		return noOfTruck;
	}
	public void setNoOfTruck(int noOfTruck) {
		this.noOfTruck = noOfTruck;
	}
	public float getWeight() {
		return weight;
	}
	public void setWeight(float weight) {
		this.weight = weight;
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	@Override
	public String toString() {
		return "Truck [shipperId=" + shipperId + ", Date=" + Date + ", loadingPoint=" + loadingPoint
				+ ", unloadingPoint=" + unloadingPoint + ", productType=" + productType + ", truckType=" + truckType
				+ ", noOfTruck=" + noOfTruck + ", weight=" + weight + ", comment=" + comment + "]";
	}
	public Truck() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Truck(int shipperId, LocalDate date, String loadingPoint, String unloadingPoint, String productType,
			String truckType, int noOfTruck, float weight, String comment) {
		super();
		this.shipperId = shipperId;
		Date = date;
		this.loadingPoint = loadingPoint;
		this.unloadingPoint = unloadingPoint;
		this.productType = productType;
		this.truckType = truckType;
		this.noOfTruck = noOfTruck;
		this.weight = weight;
		this.comment = comment;
	}
	
	
	
	
	

}
