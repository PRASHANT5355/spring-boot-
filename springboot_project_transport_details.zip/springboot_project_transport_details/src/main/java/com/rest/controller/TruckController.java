package com.rest.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.rest.entity.Truck;
import com.rest.service.TruckService;

@RestController
@RequestMapping("/api/")
public class TruckController {
	
	@Autowired
	private TruckService truckService;
	
	@PostMapping
	public ResponseEntity<Truck> createTruck(@RequestBody Truck truck){
		return  new ResponseEntity<Truck>(truckService.createTruck(truck),HttpStatus.CREATED);
		
		
	}
	
	
	@GetMapping("/getAllTruck")
	public ResponseEntity<List<Truck>> getAllTruck(){
		
		return new ResponseEntity<List<Truck>>(truckService.getAllTruck(),HttpStatus.OK);
	}

	@PutMapping("/editTruck/{shipperId}")
	public ResponseEntity<Truck> updateTruck(@PathVariable(value ="shipperId") int shipperId,@RequestBody Truck truck){
	
		return new ResponseEntity<Truck>(truckService.updateTruck(shipperId, truck),HttpStatus.OK);
	}
	
	@DeleteMapping("/deleteTruck/{shipperId}")
	public ResponseEntity<String> deleteTruck(@PathVariable int shipperId){
		return new ResponseEntity<String>(truckService.deleteTruck(shipperId),HttpStatus.OK);
	}

}
