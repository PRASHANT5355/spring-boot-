package com.rest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootProjectTransportDetailsApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootProjectTransportDetailsApplication.class, args);
	}

}
